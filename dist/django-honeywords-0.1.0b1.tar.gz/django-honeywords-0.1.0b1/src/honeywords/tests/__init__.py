"""Django Honeywords Tests __init__ Configuration
honeywords/tests/__init__.py

"""
# https://docs.djangoproject.com/en/dev/ref/applications/#for-application-authors
default_app_config = 'honeywords.tests.apps.HoneywordsTestsConfig'

