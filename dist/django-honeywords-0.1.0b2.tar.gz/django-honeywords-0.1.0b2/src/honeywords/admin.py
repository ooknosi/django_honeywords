"""Django Honeywords Admin Configuration

"""
from django.contrib import admin
from .models import Sweetwords

admin.site.register(Sweetwords)
